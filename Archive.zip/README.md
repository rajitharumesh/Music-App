# AbcCollege

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 14.1.1.

## Clone the repo

git clone https://github.com/rajitharumesh/collage.git
cd ABCCollageClient

# Install npm packages
Install the npm packages described in the package.json and verify that it works:

npm install

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.
